package Model;

public class AI {

}
